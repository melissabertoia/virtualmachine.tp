#!/bin/bash

FECHA=$(date +%Y%m%d)
HORA=$(date +%H%M%S)
LOG="/var/log/backup.log"

if [[ "$1" = "-help" ]]; then
	echo "Uso: $0 <directorio_origen>"
	echo "Este script realiza un backup comprimido del directorio de origen indicado."
	echo "El archivo comprimido generado se guarda en /backup_dir con formato:"
	echo "ANSI YYYYMMDD. EJ: <nombre_directorio>_bkp_YYYYMMDD.tar.gz"
	exit 0
fi

if [ $# -lt 1 ]; then
	echo "[$FECHA $HORA] Falta ingresar un directorio de origen." >> "$LOG"
	echo "Falta ingresar un directorio de origen"
	exit 1
fi

ORIGEN="$1"
DESTINO="/backup_dir"

if [ ! -d "$ORIGEN" ]; then
	echo "[$FECHA $HORA] El directorio de origen '$ORIGEN' no existe" >> "$LOG"
	echo "El directorio de origen ingresado no existe" 
	exit 2
else
	echo "[$FECHA $HORA] El directorio de origen existe" >> "$LOG"
fi

if [ ! -d "$DESTINO" ]; then
	echo "[$FECHA $HORA] El directorio de destino no existe o no esta montado" >> "$LOG"
	echo "El directorio de destino ingresado no existe o no esta montado" 
	exit 3
fi

ARCHIVO="$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz"
echo "[$FECHA $HORA] Nombre de archivo '$ARCHIVO' generado correctamente" >> "$LOG"

tar -czf "/tmp/$ARCHIVO" "$ORIGEN"
if [ $? -eq 0 ]; then
	echo "[$FECHA $HORA] Archivo comprimido con éxito" >> "$LOG"
else
	echo "[$FECHA $HORA] Error al comprimir el archivo" >> "$LOG"
	exit 4
fi

mv "/tmp/$ARCHIVO" "$DESTINO/"
if [ $? -eq 0 ]; then
	echo "[$FECHA $HORA] Archivo movido correctamente a '$DESTINO'" >> "$LOG"
else
	echo "[$FECHA $HORA] Error al mover el archivo a '$DESTINO'" >> "$LOG"
	exit 5
fi
